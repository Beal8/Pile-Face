﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

	Piece p;
	Animator anim;

	public Text resultatText;
	public Canvas canvas;

	int luckyPourcent;

	bool canPlay = true;


	void Start () {
		p = GameObject.FindObjectOfType<Piece> ();
		anim = p.GetComponent<Animator> ();
		canvas.enabled = false;

		luckyPourcent = Random.Range (1, 100);

		canPlay = true;
	}

	void Update () {

		if (canPlay) {
			if (Input.GetMouseButtonDown (0)) {
				Lancer ();
			}
		}
	}

	IEnumerator ShowCanvas()
	{
		yield return new WaitForSeconds (2f);
		canvas.enabled = true;
	}

	void Lancer ()
	{
		
		canvas.enabled = false;

		canPlay = false;

		if (luckyPourcent < 49) {
			anim.SetBool ("isPile", true);
			resultatText.text = "Pile";
			StartCoroutine (ShowCanvas ());
		} else if (luckyPourcent > 51) {
			anim.SetBool ("isFace", true);
			resultatText.text = "Face";
			StartCoroutine (ShowCanvas ());
		} else {
			anim.SetBool ("isTranche", true);
			resultatText.text = "Tranche";
			StartCoroutine (ShowCanvas ());
		}
	}

	public void LoadScene(int sceneBuildIndex)
	{
		SceneManager.LoadScene (sceneBuildIndex);
		Lancer ();
	}
}
